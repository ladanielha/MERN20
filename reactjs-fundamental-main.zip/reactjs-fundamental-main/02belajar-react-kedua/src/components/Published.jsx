import React from 'react'

const Published = () => {
  return (
    <h2>Published</h2>
  )
}

export default Published