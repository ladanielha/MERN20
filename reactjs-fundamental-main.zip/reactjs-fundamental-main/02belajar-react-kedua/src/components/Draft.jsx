import React from 'react'

const Draft = () => {
  return (
    <h2>Draft</h2>
  )
}

export default Draft