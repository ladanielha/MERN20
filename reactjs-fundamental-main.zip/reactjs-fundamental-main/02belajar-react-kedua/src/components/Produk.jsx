import React from 'react'

const Produk = (props) => {
  return (
    <li>Produk {props.namaProduk}</li>
  )
}

export default Produk